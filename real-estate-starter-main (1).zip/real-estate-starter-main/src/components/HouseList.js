import React from 'react';

const HouseList = () => {
  return <div>HouseList</div>;
};

export default HouseList;
