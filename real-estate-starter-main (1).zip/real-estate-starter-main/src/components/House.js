import React from 'react';

const House = () => {
  return <div>House</div>;
};

export default House;
