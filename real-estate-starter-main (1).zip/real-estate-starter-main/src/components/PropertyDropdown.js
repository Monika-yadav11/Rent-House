import React from 'react';

const PropertyDropdown = () => {
  return <div>PropertyDropdown</div>;
};

export default PropertyDropdown;
