import React from 'react';

const PriceRangeDropdown = () => {
  return <div>PriceRangeDropdown</div>;
};

export default PriceRangeDropdown;
