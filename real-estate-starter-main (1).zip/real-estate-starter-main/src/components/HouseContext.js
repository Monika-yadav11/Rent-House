import React from 'react';

const HouseContext = () => {
  return <div>HouseContext</div>;
};

export default HouseContext;
