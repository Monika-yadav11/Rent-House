import React from 'react';

const App = () => {
  return <div>react app</div>;
};

export default App;
