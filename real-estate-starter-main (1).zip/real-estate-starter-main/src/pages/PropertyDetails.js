import React from 'react';

const PropertyDetails = () => {
  return <div>PropertyDetails</div>;
};

export default PropertyDetails;
